# Pulse Runtime System (Technical SDK)

A **Pulse** is the primary executable Aurex-X experience unit (game, world, visual music, demo, or ambient runtime).

## Core types
- `PulseDefinition` (JSON schema)
- `PulseRunner` (lifecycle executor)

Implemented in `crates/aurex_pulse`.

## Lifecycle
1. `load`
2. `initialize`
3. `update`
4. `render`
5. `shutdown`

## Integration model
Pulse runtime **orchestrates existing systems** rather than replacing them:
- existing `SdfScene` scene graph
- existing generator/effect graph/automation/timeline/demo/camera stack
- existing renderer diagnostics

## Planner bridge
Pulse orchestration currently treats planning outputs as upstream inputs:
- `WorldBlueprint` captures high-level world intent.
- `GeneratorStack` deterministically expands it into scene parameters consumed by rendering.
- `RenderTheme` is the style bridge between ExperiencePlanner intent and renderer-facing configuration.

## Rendering pipeline
Pulse runtime invokes the existing renderer pipeline unchanged:
- ScenePreprocess
- EffectGraphEvaluation
- GeometrySdf
- MaterialPattern
- LightingAtmosphere
- Particles
- PostProcessing
- TemporalFeedback

## Diagnostics
Pulse-level diagnostics track lifecycle timing and frame counts, while preserving nested renderer diagnostics payloads.

## Music sequencing integration
Pulse definitions may include `music: MusicSequenceConfig`.
The runtime initializes a sequencer and updates it every frame step, exposing RhythmField modulation signals while keeping the renderer pipeline unchanged.

Rhythm integration points:
- stores `RhythmField` in pulse runtime context each update
- publishes a diagnostics rhythm summary (`beat_phase`, `bar_index`, `bass_energy`)
- applies lightweight scene modulation by scaling `scene.sdf.lighting.ambient_light` from `beat_strength` and `harmonic_energy`

## PulseGraph orchestration
`aurex_pulse::pulse_graph` adds graph-level orchestration on top of `PulseRunner`:

- `PulseGraph`
- `PulseNode`
- `PulseTransition`
- `PulseGraphRunner`

`PulseGraphRunner` wraps and coordinates `PulseRunner` instances (it does not modify renderer stages).

Supported transition kinds:
- manual trigger
- timeline threshold (`after_seconds`)
- musical cue from `RhythmField`
- generator event trigger

Example graph: `examples/pulse_graphs/electronic_journey.graph.json`

## Boot World pulse hub
Pulse definitions may include optional `boot_world` metadata for hub-style experiences.

Boot World uses:
- `BootWorldGenerator`
- `District`
- `PulsePortal`
- `BootWorldState`

The runtime tracks district/portal proximity state, and portal systems can emit manual triggers into `PulseGraphRunner` for pulse launches.

## Resonance tracker
Pulse runtime can maintain a per-player `ResonanceTracker` profile keyed by `PrimeFaction`.

Sources:
- pulse `metadata.prime_affinity`
- Boot World district visits
- Boot World portal launches

Diagnostics expose `dominant_prime` and `top_three_primes` snapshots without affecting renderer diagnostics payloads.

## Living Boot Screen
Boot World includes optional Living Boot state derived from resonance profile.

- presentation updates: dominant/top-three + visual/audio bias weights
- idle updates: deterministic warning/event-ready state machine

Idle event rules are intentionally minimal:
- first long-idle threshold => warning only
- later long-idle thresholds => `resonance_event_ready = true`

No world mutation is performed yet; this only exposes deterministic state for future systems.

## Prime Pulse megastructure
Boot World now includes an optional Prime Pulse gate-state layer with resonance-based unlock progression.

Runtime outputs:
- proximity distance to Prime Pulse
- current active resonance gate layer
- unlocked layer count
- force-field active state
- modulation hooks (`prime_pulse_intensity`, `prime_pulse_proximity`)

This remains logic/diagnostics only (no renderer stage changes, no heavy world mutation yet).

## Pulse Timeline System (app runtime integration)
`crates/aurex_app` now includes a lightweight timeline orchestration layer for scripted intros (for example `aurielle_intro`):

- `TimelineClock` (deterministic fixed-step global time)
- `PulseTimeline` (ordered timestamped events)
- `EventScheduler` (fire-once event triggering)
- `SceneManager` (scene layers + transition progression)
- `TransitionEngine` primitives (`fade`, `crossfade`, `dissolve`, `additive overlay`)
- `AudioTransport` (timestamped play/stop/one-shot cues)

This system coordinates scene activation, transitions, reveal triggers, and audio cues from one clock while preserving the existing renderer pipeline stage order.
